package com.restemployeecrud.restemployeecrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestemployeecrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
