package com.restemployeecrud.restemployeecrud.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.restemployeecrud.restemployeecrud.controller.model.Employee;
import com.restemployeecrud.restemployeecrud.repository.EmployeeRepository;



@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
	
//	@Override
//  public Employee getEmployee(int id) {
//    if(id==1) {
//    Employee employee = new Employee();
//    employee.setId(1);
//    employee.setFirstName("First");
//    employee.setLastName("Employee");
//    employee.setSalary(6000.00);
//    return employee;
//    }else {
//      Employee employee = new Employee();
//      employee.setId(id);
//      employee.setFirstName("Second");
//      employee.setLastName("Employee");
//      employee.setSalary(5000.00);
//      return employee;
//    }
//  }

  
  @Override
  public Employee createEmployee (Employee employee) {
	
	  Employee saveObject = employeeRepository.save(employee); 
	  
	  return saveObject;
  
  }
  
  
@Override
  public Employee getEmployee (int id) {
	
	  Employee getObject = employeeRepository.getById(id); 
	  
	  return getObject;
  
  }

@Override
public Employee updateEmployee (Employee employee, int id) {
	
	  Employee updateObject = employeeRepository.save(employee);
	  
	  return updateObject;

}


}
