package com.restemployeecrud.restemployeecrud.service;

import org.springframework.stereotype.Service;

import com.restemployeecrud.restemployeecrud.controller.model.Employee;

public interface EmployeeService {

	  public Employee getEmployee(int id);
	  
	  public Employee createEmployee(Employee employee);
	  
	  public Employee updateEmployee(Employee employee, int id);
	  
	  
	  
}
