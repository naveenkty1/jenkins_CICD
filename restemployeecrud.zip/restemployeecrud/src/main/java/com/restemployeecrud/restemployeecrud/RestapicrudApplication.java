package com.restemployeecrud.restemployeecrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestapicrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestapicrudApplication.class, args);
		//System.out.println("DD");
	}

}
